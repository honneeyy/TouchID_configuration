//
//  EditnoteViewController.swift
//  fingerprint_demo_s
//
//  Created by Rupesh M V on 11/22/17.
//  Copyright © 2017 Rupesh M V. All rights reserved.
//

import UIKit

class EditnoteViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet var txt_textfield: UITextField!
    @IBOutlet var txt_view: UITextView!
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    override func viewDidLoad() {
        super.viewDidLoad()
self.txt_textfield.becomeFirstResponder()
        txt_textfield.delegate = self
        // Do any additional setup after loading the view.
    }
    func textFieldShouldReturn(_ textField: UITextField!) -> Bool {
        // Resign the textfield from first responder.
        textField.resignFirstResponder()
        
        // Make the textview the first responder.
        txt_view.becomeFirstResponder()
        
        return true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
